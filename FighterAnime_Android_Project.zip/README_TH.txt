Fighter Anime - Android project

สิ่งที่มี:
- เกมต่อสู้ 2D แนวนอน
- ผู้เล่นควบคุมตัวละครด้วยปุ่มซ้าย/ขวา/กระโดด/โจมตี/ท่าไม้ตาย
- คู่ต่อสู้ AI, แถบพลังชีวิต, เวลา, ชนะ/แพ้ และปุ่มเริ่มใหม่
- ใช้ Android WebView โหลดเกมจาก assets/index.html

วิธีสร้าง APK:
1. ติดตั้ง Android Studio และ Android SDK (แนะนำ SDK Platform 35)
2. เปิดโฟลเดอร์ FighterAnime ใน Android Studio
3. รอ Gradle Sync ให้เสร็จ
4. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
5. ไฟล์ APK จะอยู่ที่ app/build/outputs/apk/debug/app-debug.apk

หมายเหตุ:
- โปรเจกต์นี้เป็นต้นแบบเริ่มต้น ยังไม่ได้คอมไพล์เป็น APK ในสภาพแวดล้อมนี้
- ต้องใช้ Android Studio/SDK และการเชื่อมต่ออินเทอร์เน็ตครั้งแรกเพื่อดาวน์โหลด Gradle/Android dependencies
